package com.example.appauth.chat;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.appauth.classes.CostumItems;
import com.example.appauth.R;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<CostumItems> {


    public CustomAdapter(@NonNull Context context,  @NonNull ArrayList<CostumItems> objects) {
        super(context, 0, objects);
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return customView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return customView(position, convertView, parent);
    }

    private View customView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {

        if(convertView==null)
            convertView = LayoutInflater.from(getContext()).
                    inflate(R.layout.custom_spinner_layout, parent, false);

        LinearLayout linearLayout =convertView.findViewById(R.id.CategoriesLinear);
        linearLayout.setGravity(Gravity.START);
        TextView spinnerText =convertView.findViewById(R.id.textCustomSpinner);
        spinnerText.setGravity(Gravity.START);
        switch (position)
        {

            case 0:
                break;

            case 1:

                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_devices_black_24dp, 0, 0, 0);
                break;
            case 2:
                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_directions_car_black_24dp, 0, 0, 0);
                break;
            case 3:
                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_brush, 0, 0, 0);
                break;
            case 4:
                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_home_black_24dp, 0, 0, 0);
                break;
            case 5:
                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_videogame, 0, 0, 0);
                break;
            case 6:
                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_child_friendly, 0, 0, 0);
                break;
            case 7:
                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_card_jobl_black_24dp, 0, 0, 0);
                break;
            case 8:
                spinnerText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_build_black_24dp, 0, 0, 0);
                break;



        }
        CostumItems items =getItem(position);

        if(items!=null)
        {
            spinnerText.setText(items.getSpinnerText());

        }
        return  convertView;
    }
}
