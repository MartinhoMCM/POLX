package com.example.appauth.proload;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.appauth.R;

public class SobreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobre);
    }
}
