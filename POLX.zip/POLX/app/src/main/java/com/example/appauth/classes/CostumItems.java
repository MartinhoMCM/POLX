package com.example.appauth.classes;

public class CostumItems {

    private String spinnerText;

    public CostumItems(String spinnerText) {
        this.spinnerText = spinnerText;
    }

    public String getSpinnerText() {

        return spinnerText;
    }

    public void setSpinnerText(String spinnerText) {
        this.spinnerText = spinnerText;
    }
}
