package com.example.appauth.home;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.appauth.R;
import com.example.appauth.chat.ChatActivity;
import com.example.appauth.models.Favority;
import com.example.appauth.models.Notifications;
import com.example.appauth.models.Posts;
import com.example.appauth.models.User;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;
import com.parse.DeleteCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import de.hdodenhof.circleimageview.CircleImageView;


public class ProductDescriptionActivity extends AppCompatActivity {

    public static String ObjectId = "objectId";

    private TextView mProdutoTitle,mProdutoDescription, mProdutoLocation,mProdutoPreco,mProdutoUserNames, mUserNumerCall;
    private ImageView mProdutoImage,mFavorityUserPost;
    private CircleImageView mProdutoUserAvatar;
    private RelativeLayout mLayoutShimmir,mLayoutInformation;
    private FloatingActionsMenu floatingActionsMenu;
    private ShimmerFrameLayout shimmer,shimmerLayout;

    Posts posts;
    private User mCurrentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_description);

        final FloatingActionButton fab1 = findViewById(R.id.actionfab_chamada);
        FloatingActionButton fabMessage = findViewById(R.id.actionfab_message);
        floatingActionsMenu = (FloatingActionsMenu) findViewById(R.id.fab);

        mProdutoTitle = (TextView) findViewById(R.id.produto_title);
        mProdutoDescription = (TextView) findViewById(R.id.produto_description);
        mProdutoLocation = (TextView) findViewById(R.id.produto_localization);
        mProdutoPreco = (TextView) findViewById(R.id.produto_preco);
        mProdutoUserNames = (TextView) findViewById(R.id.produto_user_names);
        mUserNumerCall = (TextView) findViewById(R.id.user_number_call);

        mLayoutShimmir = (RelativeLayout) findViewById(R.id.animationShimmir);
        mLayoutInformation = (RelativeLayout) findViewById(R.id.information);

        ImageView mBackHome = (ImageView) findViewById(R.id.back);
        mProdutoImage = (ImageView) findViewById(R.id.produto_image);
        mFavorityUserPost = (ImageView) findViewById(R.id.favority_user_id);
        mProdutoUserAvatar = (CircleImageView) findViewById(R.id.produto_avatar_user);

        final Intent intent = getIntent();
        final String objectId = intent.getExtras().getString(ObjectId);

        ParseQuery<Posts> postsParseQuery = Posts.getQuery();
        postsParseQuery.getInBackground(objectId, new GetCallback<Posts>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void done(final Posts posts, ParseException e) {
                if (posts != null){

                    ProductDescriptionActivity.this.posts = posts;

                    if (posts.getAuthor().getPhotoUrl().isEmpty()) {
                        mProdutoUserAvatar.setImageResource(R.drawable.placeholder);
                    } else {

                        Glide.with(ProductDescriptionActivity.this)
                                .load(posts.getAuthor().getPhotoUrl())
                                .error(R.drawable.placeholder)
                                .centerCrop()
                                .fitCenter()
                                .placeholder(R.drawable.placeholder)
                                .into(mProdutoUserAvatar);

                    }

                    //////////////////////////////////////////////////////
                    if (posts.getPostImageUrl().isEmpty()) {

                        mProdutoImage.setImageResource(R.drawable.placeholder);

                    } else {

                        Glide.with(ProductDescriptionActivity.this)
                                .load(posts.getPostImageUrl())
                                //.networkPolicy(NetworkPolicy.OFFLINE)
                                .error(R.drawable.placeholder)
                                .fitCenter()
                                .centerCrop()
                                .placeholder(R.drawable.placeholder)
                                .into(mProdutoImage);

                    }

                    mProdutoTitle.setText(ProductDescriptionActivity.this.posts.getTitle());
                    mProdutoDescription.setText(ProductDescriptionActivity.this.posts.getDescription());
                    mProdutoLocation.setText(ProductDescriptionActivity.this.posts.getLocalization());
                    mUserNumerCall.setText(ProductDescriptionActivity.this.posts.getAuthor().getNumber());
                    mProdutoPreco.setText(ProductDescriptionActivity.this.posts.getPrice());
                    mProdutoUserNames.setText(posts.getAuthor().getUserFirstName() +" " +posts.getAuthor().getUserLastName());
                    final String mNumero_Telefone = ProductDescriptionActivity.this.posts.getAuthor().getNumber();


                    mLayoutShimmir.setVisibility(View.GONE);
                    mLayoutInformation.setVisibility(View.VISIBLE);
                    floatingActionsMenu.setVisibility(View.VISIBLE);

                    fab1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            Intent i = new Intent(Intent.ACTION_DIAL);

                            i.setData(Uri.parse("tel:"+mNumero_Telefone));
                            startActivity(i);

                            Toast.makeText(getApplicationContext(), "Ligar para " +posts.getAuthor().getUserFirstName() +posts.getAuthor().getUserLastName(), Toast.LENGTH_LONG).show();
                        }
                    });

                }

            }
        });

        ParseQuery<Posts> PostQuery = Posts.getQuery();
        PostQuery.getInBackground(objectId, new GetCallback<Posts>() {
            @Override
            public void done(Posts mpost, ParseException e) {
                if (mpost != null) {

                    ProductDescriptionActivity.this.posts = mpost;
                    mCurrentUser =(User) ParseUser.getCurrentUser();

                    Log.d("temos o valor do id  ", "é " +mpost);

                    ParseQuery<Favority> favorityQuery =  Favority.getQuery();

                    favorityQuery.whereEqualTo(Favority.COL_POST, mpost);
                    favorityQuery.whereEqualTo(Favority.COL_AUTHOR, mCurrentUser);
                    favorityQuery.getFirstInBackground(new GetCallback<Favority>() {
                        @Override
                        public void done(Favority object, ParseException e) {

                            if (e == null){

                                Log.d("adicinou ", "" +object);
                                mFavorityUserPost.setImageResource(R.drawable.favorito_bold);

                            }
                        }
                    });


                }else {

                    Toast.makeText(getApplicationContext(), "post é null "+e, Toast.LENGTH_LONG).show();
                }
            }
        });

        mFavorityUserPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mFavorityUserPost.setImageResource(R.drawable.favorito_bold);

                ParseQuery<Favority> FavorityQuery = Favority.getQuery();
                User currentUser = (User)User.getCurrentUser();

                FavorityQuery.whereEqualTo(Favority.COL_AUTHOR, currentUser);
                FavorityQuery.whereEqualTo(Favority.COL_POST, posts);
                FavorityQuery.getFirstInBackground(new GetCallback<Favority>() {
                    @Override
                    public void done(Favority update, ParseException e) {
                        if (e == null) {

                            update.deleteInBackground(new DeleteCallback() {
                                public void done(ParseException e) {
                                    if (e == null) {

                                        mFavorityUserPost.setImageResource(R.drawable.favorito_normal);
                                        Toast.makeText(getApplicationContext(), R.string.deleted_update, Toast.LENGTH_LONG).show();
                                        onStart();
                                        //.notifyDataSetChanged();

                                    } else {

                                        // not deleted
                                        Toast.makeText(getApplicationContext(), "not deleted "+e, Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        } else {

                            Favority favority = new Favority();
                            favority.setPost(posts);
                            favority.setAuthor(mCurrentUser);

                            favority.saveInBackground(new SaveCallback() {
                                @Override
                                public void done(ParseException e) {
                                    if (e == null){

                                        Notifications notification = new Notifications();
                                        notification.setAuthor(mCurrentUser);
                                        notification.setToAuthor(posts.getAuthor());
                                        notification.setPost(posts);
                                        notification.setPostImage(posts.getColImage());
                                        notification.setColNotiType("favority");
                                        notification.saveInBackground(new SaveCallback() {
                                            @Override
                                            public void done(ParseException e) {
                                                if (e == null){

                                                    Toast.makeText(getApplicationContext(), "notificacao enviado ", Toast.LENGTH_LONG).show();

                                                } else {

                                                    Toast.makeText(getApplicationContext(), "notificacao nao enviado "+e, Toast.LENGTH_LONG).show();

                                                }
                                            }
                                        });

                                        // Liked
                                        mFavorityUserPost.setImageResource(R.drawable.favorito_bold);
                                        Toast.makeText(getApplicationContext(), "adicinou nos favorito ", Toast.LENGTH_LONG).show();

                                    } else {

                                        // Not liked
                                        mFavorityUserPost.setImageResource(R.drawable.favorito_normal);
                                        Toast.makeText(getApplicationContext(), "removeu dos favoritos ", Toast.LENGTH_LONG).show();

                                    }
                                }
                            });

                        }

                    }
                });

            }
        });

        mBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ProductDescriptionActivity.this, HomeActivity.class);
                startActivity(i);
            }
        });

        fabMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(posts!=null)
                {

                    if(posts.getAuthor().getObjectId().equals(mCurrentUser.getObjectId()))
                    {

                    }
                    else{
                        Intent startChat =new Intent(getApplicationContext(), ChatActivity.class);
                        startChat.putExtra(ObjectId, posts.getAuthor().getObjectId());
                        startActivity(startChat);
                    }

                }
                //Toast.makeText(getApplicationContext(), "Floating Action working", Toast.LENGTH_LONG).show();
            }
        });

     //   ActionBar actionBar =getSupportActionBar();
      //  actionBar.hide();
    }
}
